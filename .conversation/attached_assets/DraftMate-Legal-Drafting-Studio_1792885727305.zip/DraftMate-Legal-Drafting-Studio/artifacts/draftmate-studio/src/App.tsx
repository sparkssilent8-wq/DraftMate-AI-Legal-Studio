import { useEffect, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  AlertCircle, Archive, ArrowDownToLine, BookOpen, CheckCircle2, ChevronDown,
  CircleHelp, Clipboard, FilePlus2, FileSearch, FileText, FolderOpen, Gavel,
  LoaderCircle, Mic, PanelLeft, PenLine, Plus, Search, ShieldCheck, Sparkles,
  Upload, X,
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { useGenerateDraftmateDraft } from '@workspace/api-client-react';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import mammoth from 'mammoth/mammoth.browser';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

const queryClient = new QueryClient();

type Skill =
  | 'agreement-drafting'
  | 'legal-notice'
  | 'contract-review'
  | 'petition-outline'
  | 'legal-research'
  | 'document-summary';

type DraftRecord = {
  id: string;
  title: string;
  draft: string;
  skill: Skill;
  updatedAt: string;
  caveats?: string[];
};

type ReferenceRecord = {
  id: string;
  name: string;
  text: string;
  addedAt: string;
};

type CitationCheck = { label: string; found: boolean };
type RecognizerLike = {
  lang: string;
  interimResults: boolean;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

const skills: { value: Skill; label: string; short: string }[] = [
  { value: 'agreement-drafting', label: 'Agreement drafting', short: 'Agreement' },
  { value: 'legal-notice', label: 'Legal notice', short: 'Legal notice' },
  { value: 'contract-review', label: 'Contract review', short: 'Contract review' },
  { value: 'petition-outline', label: 'Petition outline', short: 'Petition' },
  { value: 'legal-research', label: 'Legal research', short: 'Research' },
  { value: 'document-summary', label: 'Document summary', short: 'Summary' },
];

const readLocal = <T,>(key: string, fallback: T): T => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? (JSON.parse(stored) as T) : fallback;
  } catch {
    return fallback;
  }
};

const stamp = (date: string) =>
  new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(date));

function Home() {
  const generate = useGenerateDraftmateDraft();
  const [section, setSection] = useState<'workspace' | 'references' | 'drafts'>('workspace');
  const [skill, setSkill] = useState<Skill>('agreement-drafting');
  const [instruction, setInstruction] = useState('');
  const [referenceText, setReferenceText] = useState('');
  const [styleText, setStyleText] = useState('');
  const [referenceName, setReferenceName] = useState('');
  const [draftTitle, setDraftTitle] = useState('');
  const [draftText, setDraftText] = useState('');
  const [caveats, setCaveats] = useState<string[]>([]);
  const [drafts, setDrafts] = useState<DraftRecord[]>(() => readLocal('draftmate:drafts', []));
  const [references, setReferences] = useState<ReferenceRecord[]>(() => readLocal('draftmate:references', []));
  const [activeDraftId, setActiveDraftId] = useState('');
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState('');
  const [citations, setCitations] = useState<CitationCheck[] | null>(null);
  const [voiceProposal, setVoiceProposal] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const recognizer = useRef<RecognizerLike | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    localStorage.setItem('draftmate:drafts', JSON.stringify(drafts));
  }, [drafts]);
  useEffect(() => {
    localStorage.setItem('draftmate:references', JSON.stringify(references));
  }, [references]);
  useEffect(() => {
    if (!toast) return;
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2800);
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, [toast]);

  const persistCurrentDraft = (title = draftTitle, draft = draftText) => {
    if (!draft.trim()) return;
    const id = activeDraftId || `draft-${Date.now()}`;
    const record: DraftRecord = { id, title: title.trim() || 'Untitled legal draft', draft, skill, updatedAt: new Date().toISOString(), caveats };
    setActiveDraftId(id);
    setDrafts((current) => [record, ...current.filter((item) => item.id !== id)]);
  };

  const createNewDraft = () => {
    setActiveDraftId('');
    setDraftTitle('');
    setDraftText('');
    setCaveats([]);
    setCitations(null);
    setErrorMessage('');
    setSection('workspace');
  };

  const openDraft = (item: DraftRecord) => {
    setActiveDraftId(item.id);
    setDraftTitle(item.title);
    setDraftText(item.draft);
    setCaveats(item.caveats || []);
    setSkill(item.skill);
    setCitations(null);
    setSection('workspace');
  };

  const addReference = (name: string, text: string) => {
    const next: ReferenceRecord = { id: `ref-${Date.now()}`, name, text, addedAt: new Date().toISOString() };
    setReferences((current) => [next, ...current]);
    setReferenceName(name);
    setReferenceText(text);
    setToast('Reference added to your local library');
  };

  const handleFile = async (file?: File) => {
    if (!file) return;
    const supported = /\.(txt|md|csv|html?|pdf|docx)$/i.test(file.name) || file.type.startsWith('text/');
    if (!supported) {
      setToast('Choose a PDF, DOCX, plain-text, Markdown, CSV, or HTML file');
      return;
    }
    try {
      let text = '';
      if (/\.pdf$/i.test(file.name) || file.type === 'application/pdf') {
        const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
        const pages: string[] = [];
        for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
          const page = await pdf.getPage(pageNumber);
          const content = await page.getTextContent();
          const items = content.items as Array<{ str?: string; hasEOL?: boolean }>;
          pages.push(items.map((item) => `${item.str ?? ''}${item.hasEOL ? '\n' : ' '}`).join('').trim());
        }
        text = pages.join('\n\n');
      } else if (/\.docx$/i.test(file.name) || file.type.includes('wordprocessingml')) {
        const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
        text = result.value;
      } else {
        text = await file.text();
      }
      if (!text.trim()) {
        setToast('No readable text was found. Scanned-image documents need OCR before use.');
        return;
      }
      addReference(file.name, text.slice(0, 18000));
      if (text.length > 18000) {
        setToast('Reference added; only the first 18,000 characters are available for this prototype');
      }
      if (fileInput.current) fileInput.current.value = '';
    } catch {
      setToast('Could not read that file');
    }
  };

  const generateDraft = () => {
    setErrorMessage('');
    setCitations(null);
    generate.mutate(
      {
        data: {
          skill,
          instruction: instruction.trim(),
          ...(referenceText.trim() ? { referenceText: referenceText.slice(0, 18000) } : {}),
          ...(styleText.trim() ? { styleText: styleText.slice(0, 8000) } : {}),
        },
      },
      {
        onSuccess: (result) => {
          const id = `draft-${Date.now()}`;
          setActiveDraftId(id);
          setDraftTitle(result.title);
          setDraftText(result.draft);
          setCaveats(result.caveats || []);
          setDrafts((current) => [
            { id, title: result.title, draft: result.draft, skill, updatedAt: new Date().toISOString(), caveats: result.caveats || [] },
            ...current.filter((item) => item.id !== id),
          ]);
          setSection('workspace');
          setToast('Draft generated and saved locally');
        },
        onError: (error) => {
          const message = error instanceof Error ? error.message : 'The request could not be completed.';
          setErrorMessage(`Draft generation failed. ${message}`);
        },
      },
    );
  };

  const checkCitations = () => {
    if (!draftText.trim()) {
      setToast('Generate or write a draft before reviewing citations');
      return;
    }
    if (!referenceText.trim()) {
      setCitations([]);
      setToast('Add reference text to check wording against it');
      return;
    }
    const candidates = Array.from(
      new Set(draftText.match(/\b(?:section|article|clause|rule|order|case|act)\s+(?:no\.?\s*)?[\w./()\-]+(?:\s+of\s+[\w\s().,-]{2,60})?/gi) || []),
    ).slice(0, 5);
    setCitations(candidates.map((label) => ({
      label,
      found: referenceText.toLocaleLowerCase().includes(label.toLocaleLowerCase()),
    })));
  };

  const startVoiceInput = () => {
    const browserWindow = window as Window & { SpeechRecognition?: new () => RecognizerLike; webkitSpeechRecognition?: new () => RecognizerLike };
    const SpeechRecognition = browserWindow.SpeechRecognition || browserWindow.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setToast('Voice input is not available in this browser');
      return;
    }
    try {
      const session = new SpeechRecognition();
      session.lang = 'en-US';
      session.interimResults = false;
      session.onresult = (event) => {
        const transcript = event.results[0]?.[0]?.transcript?.trim();
        if (transcript) setVoiceProposal(transcript);
      };
      session.onerror = () => {
        setIsListening(false);
        setToast('Voice input ended without a transcript');
      };
      session.onend = () => setIsListening(false);
      recognizer.current = session;
      setIsListening(true);
      session.start();
    } catch {
      setIsListening(false);
      setToast('Could not start voice input');
    }
  };

  const saveVoiceProposal = () => {
    setDraftText(voiceProposal);
    persistCurrentDraft(draftTitle, voiceProposal);
    setVoiceProposal('');
    setToast('Draft content replaced with the confirmed transcript');
  };

  const applyVoiceAsInstruction = () => {
    setInstruction((current) => [current.trim(), voiceProposal.trim()].filter(Boolean).join('\n'));
    setVoiceProposal('');
    setToast('Voice instruction added to the drafting brief');
  };

  const copyDraft = async () => {
    if (!draftText) return setToast('There is no draft to copy yet');
    try {
      await navigator.clipboard.writeText(`${draftTitle}\n\n${draftText}`);
      setToast('Draft copied to clipboard');
    } catch {
      setToast('Clipboard access is unavailable');
    }
  };

  const downloadDraft = () => {
    if (!draftText) return setToast('There is no draft to export yet');
    const blob = new Blob([`${draftTitle}\n\n${draftText}`], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${(draftTitle || 'legal-draft').replace(/[^\w-]+/g, '-').toLowerCase()}.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
    setToast('Draft exported as a text file');
  };

  const deleteReference = (id: string) => {
    setReferences((current) => current.filter((item) => item.id !== id));
    setToast('Reference removed from this browser');
  };
  const deleteDraft = (id: string) => {
    setDrafts((current) => current.filter((item) => item.id !== id));
    if (activeDraftId === id) createNewDraft();
    setToast('Draft removed from this browser');
  };

  const visibleDrafts = drafts.filter((item) => item.title.toLowerCase().includes(search.toLowerCase()));
  const visibleReferences = references.filter((item) => item.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="Main navigation">
        <div className="brand">
          <div className="brand-mark"><Gavel size={18} strokeWidth={1.7} /></div>
          <div><div className="brand-name">DraftMate</div><div className="brand-sub">Legal drafting studio</div></div>
        </div>
        <div className="side-label">Workspace</div>
        <nav className="nav-list" aria-label="Workspace sections">
          <button data-testid="nav-workspace" className={`nav-button ${section === 'workspace' ? 'active' : ''}`} onClick={() => setSection('workspace')} aria-current={section === 'workspace' ? 'page' : undefined}>
            <PenLine size={17} /> Drafting studio
          </button>
          <button data-testid="nav-references" className={`nav-button ${section === 'references' ? 'active' : ''}`} onClick={() => setSection('references')} aria-current={section === 'references' ? 'page' : undefined}>
            <FolderOpen size={17} /> Reference library <span style={{ marginLeft: 'auto', fontFamily: 'var(--app-font-mono)', fontSize: 10 }}>{references.length || ''}</span>
          </button>
          <button data-testid="nav-drafts" className={`nav-button ${section === 'drafts' ? 'active' : ''}`} onClick={() => setSection('drafts')} aria-current={section === 'drafts' ? 'page' : undefined}>
            <Archive size={17} /> Saved drafts <span style={{ marginLeft: 'auto', fontFamily: 'var(--app-font-mono)', fontSize: 10 }}>{drafts.length || ''}</span>
          </button>
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-note">
          <div className="review-chip"><ShieldCheck size={14} /> REVIEW IS BUILT IN</div>
          AI-generated drafts can contain errors. A qualified professional must review all content before use.
        </div>
        <div className="profile">
          <div className="profile-avatar">JD</div>
          <div><div className="profile-name">Jordan Davis</div><div className="profile-role">Independent workspace</div></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="crumb"><PanelLeft size={15} /><span>Workspace</span><span>/</span><strong>{section === 'workspace' ? 'Drafting studio' : section === 'references' ? 'Reference library' : 'Saved drafts'}</strong></div>
          <div className="top-actions">
            <div className="local-tag"><span className="local-dot" /> Stored in this browser</div>
            <button className="icon-button" title="Help and review guidance" aria-label="Help and review guidance" data-testid="button-help" onClick={() => setToast('DraftMate assists with drafting. It does not verify legal authorities or replace professional judgment.')}>
              <CircleHelp size={16} />
            </button>
          </div>
        </header>

        <div className="content-wrap">
          {section === 'workspace' ? (
            <>
              <div className="page-heading">
                <div><div className="eyebrow">LEGAL WORKSPACE / 01</div><h1>Draft with your sources.</h1><p className="page-intro">Build a working draft from your instructions and reference material.</p></div>
                <button className="subtle-button" data-testid="button-new-draft" onClick={createNewDraft}><Plus size={14} /> New draft</button>
              </div>
              <div className="work-grid">
                <section className="panel input-panel" aria-label="Draft instructions">
                  <div className="panel-head"><div className="panel-title">Draft instructions</div><span className="panel-kicker">INPUT</span></div>
                  <div className="field">
                    <label className="field-label" htmlFor="skill-select">Drafting task <small>REQUIRED</small></label>
                    <select id="skill-select" className="select-control" value={skill} onChange={(event) => setSkill(event.target.value as Skill)} data-testid="select-drafting-task">
                      {skills.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                    </select>
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="instruction-input">What should the draft do? <small>{instruction.length}/4000</small></label>
                    <textarea id="instruction-input" className="text-control instruction-control" maxLength={4000} placeholder="Describe the parties, purpose, key terms, jurisdiction, and outcome you need…" value={instruction} onChange={(event) => setInstruction(event.target.value)} data-testid="input-instruction" />
                    <div className="inline-hint"><Sparkles size={12} /> Specific facts lead to more useful first drafts.</div>
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="reference-input">Reference material <small>OPTIONAL · 18,000 CHAR MAX</small></label>
                    <textarea id="reference-input" className="text-control reference-control" maxLength={18000} placeholder="Paste clauses, facts, correspondence, or source excerpts. Checks only compare against text you provide." value={referenceText} onChange={(event) => setReferenceText(event.target.value)} data-testid="input-reference" />
                    <div className="upload-row">
                      <button className="upload-button" type="button" onClick={() => fileInput.current?.click()} data-testid="button-upload-reference"><Upload size={13} /> Add a document</button>
                      {referenceName && <span className="file-name" title={referenceName}>{referenceName}</span>}
                    </div>
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="style-input">Style guide <small>OPTIONAL · 8,000 CHAR MAX</small></label>
                    <textarea id="style-input" className="text-control style-control" maxLength={8000} placeholder="Paste a preferred clause, tone, or formatting example." value={styleText} onChange={(event) => setStyleText(event.target.value)} data-testid="input-style-guide" />
                  </div>
                  {errorMessage && <div className="error-box" role="alert">{errorMessage}</div>}
                  <div className="generate-wrap">
                    <button className="primary-button" disabled={!instruction.trim() || generate.isPending} onClick={generateDraft} data-testid="button-generate-draft">
                      {generate.isPending ? <><LoaderCircle size={15} className="animate-spin" /> Preparing draft…</> : <><Sparkles size={15} /> Generate working draft</>}
                    </button>
                    <div className="secure-copy">Selected text and instructions are sent to OpenAI. Files and saved drafts stay in this browser.</div>
                  </div>
                </section>

                <section className="panel draft-panel" aria-label="Editable draft">
                  <div className="draft-toolbar">
                    <div className="draft-status"><span className="local-dot" /> {draftText ? 'Editable working draft' : 'Draft canvas'} <ChevronDown size={12} /></div>
                    <div className="draft-actions">
                      <button className="tiny-action" data-testid="button-voice-input" onClick={isListening ? () => recognizer.current?.stop() : startVoiceInput} aria-label={isListening ? 'Stop voice input' : 'Start voice input'}>{isListening ? <><LoaderCircle size={13} /> Listening</> : <><Mic size={13} /> Voice input</>}</button>
                      <button className="tiny-action" data-testid="button-copy-draft" onClick={() => void copyDraft()}><Clipboard size={13} /> Copy</button>
                      <button className="tiny-action" data-testid="button-export-draft" onClick={downloadDraft}><ArrowDownToLine size={13} /> Export</button>
                    </div>
                  </div>
                  {draftText ? (
                    <>
                      <div className="document-sheet">
                        <input aria-label="Draft title" className="draft-title" value={draftTitle} onChange={(event) => { setDraftTitle(event.target.value); persistCurrentDraft(event.target.value, draftText); }} onBlur={() => persistCurrentDraft()} placeholder="Untitled legal draft" data-testid="input-draft-title" />
                        <div className="draft-meta"><span>{skills.find((item) => item.value === skill)?.short.toUpperCase()}</span><span>·</span><span>LOCAL WORKING COPY</span><span>·</span><span>{draftText.split(/\s+/).filter(Boolean).length} WORDS</span></div>
                        {caveats.length > 0 && <div className="caveat-list" role="note" data-testid="draft-caveats"><div className="caveat-heading"><AlertCircle size={13} /> Points to verify</div>{caveats.map((caveat, index) => <div className="caveat-item" key={`${index}-${caveat}`}>{caveat}</div>)}</div>}
                        <textarea aria-label="Draft text" className="draft-body" value={draftText} onChange={(event) => { setDraftText(event.target.value); persistCurrentDraft(draftTitle, event.target.value); }} placeholder="Your draft will appear here…" data-testid="textarea-draft" />
                      </div>
                      <div className="review-banner"><AlertCircle size={15} /><span><strong>Professional review required.</strong> Confirm all facts, legal references, dates, and obligations before relying on or sharing this AI-generated draft.</span></div>
                    </>
                  ) : (
                    <>
                      <div className="draft-empty">
                        <div><div className="empty-mark"><FileText size={20} /></div><div className="empty-title">A clear page, ready for your brief.</div><p className="empty-copy">Add your instructions, include source text when useful, then generate an editable first draft.</p></div>
                      </div>
                      <div className="review-banner"><ShieldCheck size={15} /><span><strong>Human judgment stays central.</strong> Generated content is a starting point—not legal advice or verified authority.</span></div>
                    </>
                  )}
                </section>

                <aside className="right-column" aria-label="Draft review and references">
                  <section className="panel side-panel">
                    <div className="panel-head"><div className="panel-title">Review signals</div><span className="panel-kicker">CHECKS</span></div>
                    <div className="confidence-card">
                      <div className="confidence-head"><span>Source grounding</span><span className="signal"><AlertCircle size={12} /> HUMAN REVIEW</span></div>
                      <div className="confidence-line"><div className="confidence-fill" /></div>
                      <p className="confidence-copy">{referenceText.trim() ? 'Reference text provided. Wording checks only indicate what appears in your supplied text.' : 'No reference text supplied yet. Add source material to enable text-only wording checks.'}</p>
                      <button className="check-button" onClick={checkCitations} data-testid="button-check-citations"><FileSearch size={13} /> Check wording in my references</button>
                      {citations && (
                        <div className="citation-results" role="status" data-testid="citation-results">
                          {citations.length ? citations.map((citation, index) => <div className="citation-item" key={`${citation.label}-${index}`}><span>{citation.found ? <CheckCircle2 size={13} /> : <AlertCircle size={13} />}</span><span>{citation.found ? 'Found in your provided text: ' : 'Not found in your provided text: '}{citation.label}</span></div>) : <div className="side-empty">{referenceText.trim() ? 'No citation-like references detected in this draft.' : 'No reference text is available to compare. Add source material in the instruction panel.'}</div>}
                          <div className="citation-note">This is a text match against material you supplied only. No law, case, or authority has been independently verified.</div>
                        </div>
                      )}
                    </div>
                  </section>
                  <section className="panel side-panel">
                    <div className="panel-head"><div className="panel-title">Reference sources</div><button className="tiny-action" onClick={() => setSection('references')} data-testid="button-open-references">View all <ArrowDownToLine size={12} /></button></div>
                    {references.length ? <div className="doc-list">{references.slice(0, 3).map((item) => (
                      <button className="doc-row" key={item.id} onClick={() => { setReferenceName(item.name); setReferenceText(item.text); setSection('workspace'); setToast('Reference loaded into this draft'); }} data-testid={`reference-item-${item.id}`}>
                        <span className="doc-icon"><FileText size={14} /></span><span style={{ minWidth: 0 }}><span className="doc-name" style={{ display: 'block' }}>{item.name}</span><span className="doc-sub">{item.text.length.toLocaleString()} CHAR · LOCAL</span></span>
                      </button>
                    ))}</div> : <div className="side-empty">Add source material to keep useful references close at hand.</div>}
                  </section>
                  <section className="panel side-panel">
                    <div className="panel-head"><div className="panel-title">Recent drafts</div><span className="panel-kicker">{drafts.length} SAVED</span></div>
                    {drafts.length ? <div className="doc-list">{drafts.slice(0, 3).map((item) => (
                      <button className="doc-row" key={item.id} onClick={() => openDraft(item)} data-testid={`draft-item-${item.id}`}>
                        <span className="doc-icon"><FileText size={14} /></span><span style={{ minWidth: 0 }}><span className="doc-name" style={{ display: 'block' }}>{item.title}</span><span className="doc-sub">{stamp(item.updatedAt)}</span></span>
                      </button>
                    ))}</div> : <div className="side-empty">Your generated drafts will be saved here automatically.</div>}
                  </section>
                </aside>
              </div>
            </>
          ) : (
            <section className="library-view">
              <div className="page-heading">
                <div><div className="eyebrow">YOUR MATERIAL / 0{section === 'references' ? '2' : '3'}</div><h1>{section === 'references' ? 'Reference library.' : 'Saved drafts.'}</h1><p className="page-intro">{section === 'references' ? 'Source material stored locally for your drafting sessions.' : 'Working copies stay on this device until you choose to export them.'}</p></div>
                {section === 'references' ? <button className="subtle-button" onClick={() => { setSection('workspace'); fileInput.current?.click(); }} data-testid="button-add-reference-library"><Plus size={14} /> Add reference</button> : <button className="subtle-button" onClick={createNewDraft} data-testid="button-create-draft-library"><Plus size={14} /> New draft</button>}
              </div>
              <div className="library-tools">
                <label className="search-wrap"><Search size={15} /><input className="search-input" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={`Search ${section === 'references' ? 'references' : 'drafts'}…`} aria-label={`Search ${section}`} data-testid="input-library-search" /></label>
                <div className="local-tag"><span className="local-dot" /> Private to this browser</div>
              </div>
              <div className="panel library-list">
                {section === 'references' ? visibleReferences.length ? visibleReferences.map((item) => (
                  <div className="library-item" key={item.id} data-testid={`library-reference-${item.id}`}>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center', minWidth: 0 }}><span className="doc-icon"><BookOpen size={15} /></span><div><div className="library-title">{item.name}</div><div className="library-info">{item.text.length.toLocaleString()} CHARACTERS · ADDED {stamp(item.addedAt)}</div></div></div>
                    <div className="library-item-actions"><button className="subtle-button" onClick={() => { setReferenceName(item.name); setReferenceText(item.text); setSection('workspace'); setToast('Reference loaded into this draft'); }} data-testid={`button-use-reference-${item.id}`}><FilePlus2 size={13} /> Use in draft</button><button className="icon-button" aria-label={`Remove ${item.name}`} onClick={() => deleteReference(item.id)} data-testid={`button-delete-reference-${item.id}`}><X size={14} /></button></div>
                  </div>
                )) : <div className="draft-empty"><div><div className="empty-mark"><FolderOpen size={19} /></div><div className="empty-title">No references saved yet.</div><p className="empty-copy">Add a PDF, Word file, or text document to keep source material available in this browser.</p></div></div>
                  : visibleDrafts.length ? visibleDrafts.map((item) => (
                    <div className="library-item" key={item.id} data-testid={`library-draft-${item.id}`}>
                      <button className="doc-row" style={{ padding: 0 }} onClick={() => openDraft(item)} data-testid={`button-open-draft-${item.id}`}><span className="doc-icon"><FileText size={15} /></span><span><span className="library-title">{item.title}</span><span className="library-info" style={{ display: 'block' }}>{skills.find((option) => option.value === item.skill)?.label.toUpperCase()} · UPDATED {stamp(item.updatedAt)}</span></span></button>
                      <div className="library-item-actions"><button className="subtle-button" onClick={() => openDraft(item)} data-testid={`button-edit-draft-${item.id}`}><PenLine size={13} /> Open draft</button><button className="icon-button" aria-label={`Delete ${item.title}`} onClick={() => deleteDraft(item.id)} data-testid={`button-delete-draft-${item.id}`}><X size={14} /></button></div>
                    </div>
                  )) : <div className="draft-empty"><div><div className="empty-mark"><Archive size={19} /></div><div className="empty-title">No saved drafts yet.</div><p className="empty-copy">Generated drafts and your edits are stored locally in this browser.</p></div></div>}
              </div>
            </section>
          )}
        </div>
      </main>
      {toast && <div className="toast-message" role="status" data-testid="status-toast">{toast}</div>}
      {voiceProposal && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setVoiceProposal(''); }}>
          <section className="confirm-modal" role="dialog" aria-modal="true" aria-labelledby="voice-confirm-title">
            <h2 id="voice-confirm-title">Add this transcript to the draft?</h2>
            <p>Review the recognized wording, then choose whether to add it as an instruction or replace the current draft. Cancelling leaves both untouched.</p>
            <div style={{ background: '#f2f1e9', border: '1px solid #e4e2d8', borderRadius: 5, padding: 12, marginTop: 14, fontSize: 12, lineHeight: 1.6, color: '#47534f' }}>{voiceProposal}</div>
            <div className="modal-actions"><button onClick={() => setVoiceProposal('')} data-testid="button-cancel-voice">Cancel</button><button onClick={applyVoiceAsInstruction} data-testid="button-voice-as-instruction">Add as instruction</button><button className="confirm" onClick={saveVoiceProposal} data-testid="button-confirm-voice">Replace draft content</button></div>
          </section>
        </div>
      )}
                      <input ref={fileInput} type="file" accept=".txt,.md,.csv,.html,.htm,.pdf,.docx,text/*,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" hidden onChange={(event) => void handleFile(event.target.files?.[0])} data-testid="input-reference-file" />
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
