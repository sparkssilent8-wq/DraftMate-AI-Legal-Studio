# DraftMate Legal Drafting Studio

A prototype legal drafting workspace for creating editable first drafts from user instructions and reference documents, with local document libraries, dictation, and clear review limitations.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/draftmate-studio` — drafting workspace UI and local browser storage
- `artifacts/api-server/src/routes/draftmate.ts` — AI draft-generation endpoint
- `lib/api-spec/openapi.yaml` — source of truth for the generated-draft API contract

## Architecture decisions

- Reference and draft libraries are stored in the user's browser; selected excerpts and instructions are sent to OpenAI only when draft generation is requested.
- Citation checks report text matches against supplied reference material only; they do not verify legal authority or replace professional review.
- This is a hackathon prototype without user accounts; do not publish it for public use until access control and usage protections are added.

## Product

Users can create and edit working legal drafts, upload reference files, reuse local materials, compare citation-like wording against supplied text, dictate instructions, and export draft text. AI output is not legal advice and must be reviewed by a qualified professional.

## User preferences

No additional project-specific preferences recorded.

## Gotchas

- Uploaded scanned PDFs need OCR before their text can be used.
- The OpenAI key is a Replit Secret; never expose it to frontend code or logs.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
